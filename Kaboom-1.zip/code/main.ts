import kaboom from "kaboom"
import "kaboom/global"


kaboom()


loadSprite("bean", "sprites/bean.png")


add([
	
	sprite("bean"),
	pos(80, 40),
	area(),
])


onClick(() => {
	addKaboom(mousePos())
})


onKeyPress("b", burp)